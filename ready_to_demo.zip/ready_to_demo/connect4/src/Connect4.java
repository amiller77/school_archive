import javafx.application.Application;

import view.Connect4View;

public class Connect4 {

	// launches the view:
	public static void main(String[] args) {
		Application.launch(Connect4View.class,args);
	}

}